import 'package:flutter/material.dart';

class Synchronization extends StatefulWidget {
  const Synchronization({super.key});

  @override
  State<Synchronization> createState() => _SynchronizationState();
}

class _SynchronizationState extends State<Synchronization> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(child: Text('Version compatibility issue')),
    );
  }
}
