// import 'package:flutter/material.dart';
// import 'package:mac__tools/kundan/submit_order.dart';
// import 'invoices.dart';
// import 'master_order.dart';

// void main() {
//   runApp(MyApp());
// }

// // class MyApp extends StatelessWidget {
// //   @override
// //   Widget build(BuildContext context) {
// //     return MaterialApp(
// //       debugShowCheckedModeBanner: false,
// //       title: 'Order Procurement',
// //       theme: ThemeData(
// //         primarySwatch: Colors.red,
// //       ),
// //       home: HomePage(),
// //     );
// //   }
// // }

// // class HomePage extends StatelessWidget {
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: Text('Invoices'),
// //       ),
// //       body: Center(
// //         child: ElevatedButton(
// //           onPressed: () {
// //             Navigator.push(
// //               context,
// //               MaterialPageRoute(builder: (context) => InvoicesPage()),
// //             );
// //           },
// //           child: Text('Invoices'),
// //         ),
// //       ),
// //     );
// //   }
// // }

// class MyApp extends StatefulWidget {
//   const MyApp({super.key});

//   // @override
//   State<MyApp> createState() => _MyAppState();
// }

// class _MyAppState extends State<MyApp> {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: 'Order Procurement',
//       theme: ThemeData(
//         primarySwatch: Colors.red,
//       ),
//       home: HomePage(),
//     );
//   }
// }
// // debugShowCheckedModeBanner: false,
// // home: Scaffold(
// //   appBar: AppBar(
// //     title: Text('Order Procurement'),
// //  ),

// class HomePage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(
//           title: Text('Order Procurement'),
//         ),
//         body: order_procurement());
//   }
// }

// class order_procurement extends StatelessWidget {
//   const order_procurement({
//     super.key,
//   });

//   @override
//   Widget build(BuildContext context) {
//     return order_buttons();
//   }
// }


