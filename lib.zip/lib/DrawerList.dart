// import 'package:flutter/material.dart';

// class DrawerList extends StatefulWidget {
//   const DrawerList({super.key});

//   @override
//   State<DrawerList> createState() => _DrawerListState();
// }

// class _DrawerListState extends State<DrawerList> {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       child: Column(
//         children: [MenuItem(), MenuItem()],
//       ),
//     );
//   }
// }

// Widget MenuItem() {
//   return Material(
//     child: InkWell(
//       onTap: () {},
//       child: Padding(
//         padding: EdgeInsets.all(10),
//         child: IconButton(
//           onPressed: () {},
//           icon: Icon(
//             Icons.home,
//             color: Colors.black,
//           ),
//         ),
//       ),
//     ),
//   );
// }
